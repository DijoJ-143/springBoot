package com.ust.springboot.assesment;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.springboot.assesment.model.Sum;

@SpringBootTest
class AssessmentApplicationTests {

	@Autowired
	Sum sum;

	@Test
	void contextLoads() {
		assertEquals(2, sum.SumofTwoNumbers(1, 1), "must be 2"); // This should pass
	}

	@Test
	void testSumOfTwoNumbersFailure() {
		assertEquals(3, sum.SumofTwoNumbers(1, 1), "must be 3"); // This should fail
	}
}
