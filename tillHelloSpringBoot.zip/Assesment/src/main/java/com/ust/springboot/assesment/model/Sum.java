package com.ust.springboot.assesment.model;

import org.springframework.stereotype.Controller;

@Controller
public class Sum {

	public int SumofTwoNumbers(int a, int b) {
		return a + b;
	}

}
