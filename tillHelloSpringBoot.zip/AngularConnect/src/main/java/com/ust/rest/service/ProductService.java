package com.ust.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.rest.model.Product;
import com.ust.rest.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productrepo;

	// get all product
	public List<Product> getAllProducts() {
		return productrepo.findAll();
	}

	// get by id

	public Optional<Product> getProductByid(Long id) {

		return productrepo.findById(id);

	}

	// add product
	public Product addProduct(Product product) {
		return productrepo.save(product);
	}

	// update
	public Product updateProduct(Long id, Product product) {
		if (productrepo.existsById(id)) {
			product.setId(id);
			return productrepo.save(product);
		} else
			return null;

	}

	// delete with boolean output
	public boolean deleteProduct(Long id) {
		if (productrepo.existsById(id)) {
			productrepo.deleteById(id);
			return true;
		}
		return false;
	}

}
