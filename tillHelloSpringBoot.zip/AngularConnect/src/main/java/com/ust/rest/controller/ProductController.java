package com.ust.rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.rest.model.Product;
import com.ust.rest.service.ProductService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController {

	@Autowired
	private ProductService productservice;

	// receives a list of products
	@GetMapping("/")
	public List<Product> getAllProducts() {
		return productservice.getAllProducts();
	}

	// by id
	@GetMapping("/products/{id}") // Fixed the endpoint path
	public ResponseEntity<Product> getProductById(@PathVariable("id") Long id) {
		Optional<Product> product = productservice.getProductByid(id);

		return product.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
	}

	// post mapping
	@PostMapping("/products/new") // Specified the correct path
	public ResponseEntity<Product> createProduct(@RequestBody Product product) {
		Product createdProduct = productservice.addProduct(product);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdProduct);
	}

	// put
	@PutMapping("/products/{id}") // Fixed the endpoint path
	public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product product) {
		Product updatedProduct = productservice.updateProduct(id, product);
		return updatedProduct != null ? ResponseEntity.ok(updatedProduct)
				: ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}

	// delete
	@DeleteMapping("/products/{id}")
	// Fixed the endpoint path
	public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
		return productservice.deleteProduct(id) ? ResponseEntity.noContent().build()
				: ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
}
