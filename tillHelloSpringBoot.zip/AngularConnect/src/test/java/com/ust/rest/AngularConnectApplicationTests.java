package com.ust.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
