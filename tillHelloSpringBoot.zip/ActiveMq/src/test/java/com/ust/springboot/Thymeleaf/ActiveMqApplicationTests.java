package com.ust.springboot.Thymeleaf;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.springboot.Thymeleaf.sender.MessageSender;

@SpringBootTest
class ActiveMqApplicationTests {

	@Autowired
	private MessageSender ms;
	
	@Test
	void sendMessage() {
		
		ms.send("first message");
		
	}

}
