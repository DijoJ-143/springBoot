package com.ust.springboot.Thymeleaf.sender;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Listener {
	@JmsListener(destination="${springjms.myQueue}")
	public void receive(String message) {
		System.out.println("message received------>"+message);
		
	}

}
