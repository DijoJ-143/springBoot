package com.ust.rest.expensetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
