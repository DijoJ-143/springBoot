package com.ust.rest.expensetracker.service;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;
import com.ust.rest.expensetracker.model.Expense;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.List;

@Service
public class PdfService {

    @Autowired
    private ExpenseService expenseService;

    public void generateExpensePdf(Long userId, HttpServletResponse response) throws DocumentException, IOException {
        List<Expense> expenses = expenseService.getExpensesByUserId(userId);

        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());
        document.open();

        document.add(new Phrase("Expense Report"));
        document.add(Chunk.NEWLINE);

        for (Expense expense : expenses) {
            document.add(new Phrase("Description: " + expense.getDescription()));
            document.add(Chunk.NEWLINE);
            document.add(new Phrase("Amount: " + expense.getAmount()));
            document.add(Chunk.NEWLINE);
            document.add(new Phrase("Date: " + expense.getDate()));
            document.add(Chunk.NEWLINE);
            document.add(new Phrase("Category: " + expense.getCategory()));
            document.add(Chunk.NEWLINE);
            document.add(Chunk.NEWLINE);
        }

        document.close();
    }
}
