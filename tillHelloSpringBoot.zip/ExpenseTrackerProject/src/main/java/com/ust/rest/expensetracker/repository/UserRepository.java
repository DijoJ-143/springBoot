package com.ust.rest.expensetracker.repository;

import com.ust.rest.expensetracker.config.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // Use findByUsername to find users by their username instead of email
    User findByUsername(String username); // This should work now
}
