package com.ust.rest.expensetracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseTrackerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpenseTrackerProjectApplication.class, args);
	}

}
