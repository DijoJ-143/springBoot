package com.ust.rest.expensetracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.rest.expensetracker.config.User;
import com.ust.rest.expensetracker.model.Expense;
import com.ust.rest.expensetracker.service.ExpenseService;
import com.ust.rest.expensetracker.service.UserService;

@Controller
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @Autowired
    private UserService userService;

    @GetMapping("/expenses")
    public String showExpensesPage(Model model, @RequestParam Long userId) {
        User user = userService.findByUsername("username");
        model.addAttribute("expenses", expenseService.getExpensesByUserId(userId));
        model.addAttribute("user", user);
        return "expenses";
    }

    @PostMapping("/add-expense")
    public String addExpense(@ModelAttribute Expense expense) {
        expenseService.saveExpense(expense);
        return "redirect:/expenses?userId=" + expense.getUser().getId();
    }
}
