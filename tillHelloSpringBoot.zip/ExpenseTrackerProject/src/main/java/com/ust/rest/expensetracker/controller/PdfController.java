package com.ust.rest.expensetracker.controller;

import com.ust.rest.expensetracker.service.PdfService;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class PdfController {

    @Autowired
    private PdfService pdfService;

    @GetMapping("/download-expenses-pdf")
    public void downloadExpensesPdf(@RequestParam Long userId, HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=\"expenses-report.pdf\"");

        try {
            pdfService.generateExpensePdf(userId, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
