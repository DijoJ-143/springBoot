package com.ust.rest.expensetracker.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.rest.expensetracker.controller.ExpenseController;
import com.ust.rest.expensetracker.model.Expense;
import com.ust.rest.expensetracker.repository.ExpenseRepository;

@Service
public class ExpenseService {

	@Autowired
	private ExpenseRepository expenseRepository;

	private static final Logger logger = LoggerFactory.getLogger(ExpenseController.class);
	// save expense: create
	public Expense saveExpense(Expense expense) {
	    logger.info("Saving expense: " + expense);

		return expenseRepository.save(expense);

	}


	// get list of expenses: read
	public List<Expense> getAllExpenses() {
		
		return expenseRepository.findAll();
	}

	// get by id : read
	public Expense getexpenseByid(Long id) {

		return expenseRepository.findById(id).orElse(null);

	}

	// update expense :update
	public Expense updateExpense(Long id, Expense updatedExpense) {

		return expenseRepository.findById(id).map(e -> {

			e.setDescription(updatedExpense.getDescription());
			e.setPrice(updatedExpense.getPrice());

			return expenseRepository.save(e);

		}).orElse(null);

	}

	// delete all expense : delete
	public boolean deleteExpenseById(Long id) {

		if (!expenseRepository.existsById(id)) {

			return false;

		}
		expenseRepository.deleteById(id);
		return true;

	}

}
