package com.ust.rest.expensetracker.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.rest.expensetracker.model.Expense;
import org.springframework.stereotype.Repository;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {

}
