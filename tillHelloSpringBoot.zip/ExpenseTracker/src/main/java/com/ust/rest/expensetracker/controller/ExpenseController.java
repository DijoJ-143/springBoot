package com.ust.rest.expensetracker.controller;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ust.rest.expensetracker.model.Expense;
import com.ust.rest.expensetracker.service.ExpenseService;

@Controller
public class ExpenseController {

	@Autowired
	private ExpenseService service;

	// navigate to home page
	@GetMapping("/")
	public String homePage(Model model) {

		List<Expense> expenses = service.getAllExpenses();

		BigDecimal amount = expenses.stream().map(Expense::getPrice).reduce(BigDecimal.ZERO, BigDecimal::add);

		model.addAttribute("expenses", expenses);
		model.addAttribute("amount", amount);

		return "index";

	}

	// adding an expense
	/*
	 * navigate to add expense page 1.expense 2.model
	 */

	@GetMapping("/addExpense")
	public String addExpense(Model model) {

		model.addAttribute("Expense", new Expense());

		return "add-expense";

	}

	/*
	 * saving an expense
	 */
	private static final Logger logger = LoggerFactory.getLogger(ExpenseController.class);

	@PostMapping("/saveExpense")
	public String saveExpense(@ModelAttribute("Expense") Expense expense, Model model) {
	    logger.info("Saving expense: " + expense);
	    service.saveExpense(expense);
	    return "redirect:/";
	}


	 // Navigate to edit page for editing expense
    @GetMapping("/editExpense/{id}")
    public String editExpense(@PathVariable("id") Long id, Model model) {
        Expense editedExpense = service.getexpenseByid(id);
        if (editedExpense == null) {
            model.addAttribute("error", "Update failed: Expense not found");
            return "error";  // Display error page
        }
        model.addAttribute("EditedExpense", editedExpense);
        return "update-expense";  // Display the edit form
    }

	/*
	 * Saving an update
	 * 
	 */

	@PostMapping("/updateExpense/{id}")
	public String updateExpense(@PathVariable("id") Long id, @ModelAttribute("EditedExpense") Expense updatedExpense) {

		service.updateExpense(id, updatedExpense);
		return "redirect:/";
	}

	/*
	 * delete an expense need to know id if found delete
	 */

	@GetMapping("/delete/{id}")
	public String deleteExpense(@PathVariable("id") Long id, Model model) {

		Boolean deleted = service.deleteExpenseById(id);

		if (!deleted) {
			model.addAttribute("error", "Deletion failed");
			return "redirect:/";

		}

		return "redirect:/";

	}

}
