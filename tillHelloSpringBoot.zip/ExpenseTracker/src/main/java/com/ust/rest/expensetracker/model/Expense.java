package com.ust.rest.expensetracker.model;

import java.math.BigDecimal;

import jakarta.validation.constraints.*;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Expense {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotNull(message = "ID must not be null")
	private Long id;

	// discription i.e.. name
	@NotNull(message = "Need an description of product")
	private String description;

	// price
	@NotNull(message = "Price cannot be null")
	@Min(value = 0, message = "Price must be greater than or equal to 0")
	private BigDecimal price;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

}
