package com.ust.springboot.weatherapp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.ust.springboot.weatherapp.model.WeatherResponse;

@Controller
public class WeatherController {

	@Value("${apikey}")
	private String apiKey;

//navigating to index page
	@GetMapping("/")
	public String getIndex() {
		return "index";
	}

//navigating to specific cities weather details

	@GetMapping("/weather")
	public String getWeather(@RequestParam("city") String city, Model model) {
		
		String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

		RestTemplate restTemplate = new RestTemplate();

		WeatherResponse response = restTemplate.getForObject(url, WeatherResponse.class);

		if (response != null) {
			model.addAttribute("city", response.getName());
			model.addAttribute("country", response.getSys().getCountry());
			model.addAttribute("description", response.getWeather().get(0).getDescription());
			model.addAttribute("temperature", response.getMain().getTemp());
			model.addAttribute("humidity", response.getMain().getHumidity());
			model.addAttribute("windSpeed", response.getWind().getSpeed());
			//css weather library 
			String weather_icon="wi wi-own"+response.getWeather().get(0).getId();

		} else {
			model.addAttribute("error", "city not found");
		}

		return "weather";
	}

}
