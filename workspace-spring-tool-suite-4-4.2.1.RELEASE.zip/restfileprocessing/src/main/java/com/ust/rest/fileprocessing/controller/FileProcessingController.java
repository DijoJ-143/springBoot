package com.ust.rest.fileprocessing.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class FileProcessingController {

	@Value("${dest}")
	private String dest;

	@PostMapping("/upload/files/")
	public boolean upload(@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException {

		file.transferTo((new File(dest + file.getOriginalFilename())));

		return true;

	}

	@GetMapping("/download/{filename}")
	public ResponseEntity<byte[]> download(@PathVariable("filename") String filename) throws IOException {

		//reads data in bytes 
		byte[] filedata = Files.readAllBytes(new File(dest + filename).toPath());
		
//		need for an headers to specify the types of data
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_JPEG);

		//returning with bytes,header and the status 
		return new ResponseEntity<byte[]>(filedata, headers, HttpStatus.OK);

	}

}
