package com.ust.rest.fileprocessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfileprocessingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfileprocessingApplication.class, args);
	}

}
