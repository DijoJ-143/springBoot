package com.ust.rest.fileprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfileprocessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
