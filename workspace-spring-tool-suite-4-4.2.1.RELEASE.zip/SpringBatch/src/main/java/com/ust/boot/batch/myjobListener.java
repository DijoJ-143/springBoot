package com.ust.boot.batch;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class myjobListener implements JobExecutionListener {

	@Override
	public void beforeJob(JobExecution execution) {
		System.out.println("{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{job started ");
	}

	@Override
	public void afterJob(JobExecution execution) {
		System.out.println("[{{{{{{{{{{{{{{{{{job execution ended : " + execution.getStatus().toString());

	}
}
