package com.ust.boot.batch;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

public class Reader implements ItemReader<String> {

	public int count;
	public String[] data = { "Java", "Springboot", "Angular" };

	@Override
	public String read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		// TODO Auto-generated method stub
		System.out.println("**************************inside reader:*********************************");
		if (count < data.length) {
			return data[count++];
		} else
			count = 0;
		return null;
	}

}
