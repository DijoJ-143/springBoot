package com.ust.rest.userlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleUserApplication.class, args);
	}

}
