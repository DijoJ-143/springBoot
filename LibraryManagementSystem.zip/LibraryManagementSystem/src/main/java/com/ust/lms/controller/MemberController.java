package com.ust.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ust.lms.model.Member;
import com.ust.lms.repository.MemberRepository;

@Controller
public class MemberController {
	
	@Autowired
	private MemberRepository mrepo;

	// get mapping
	
	@GetMapping("/members")
	public String listsMembers(Model model) {
		model.addAttribute("members", mrepo.findAll());
		return "members";
	}

	@GetMapping("/member/new")
	public String addMembers(Model model) {

		Member m = new Member();
		model.addAttribute("member", m);

		return "create_member";

	}

	// post mapping

	@PostMapping("/member")
	public String saveMembers(Member member) {
		mrepo.save(member);
		return "redirect:/members";

	}
	

}
