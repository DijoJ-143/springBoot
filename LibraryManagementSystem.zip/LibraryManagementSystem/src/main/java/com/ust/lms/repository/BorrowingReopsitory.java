package com.ust.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.lms.model.Borrowing;

public interface BorrowingReopsitory extends JpaRepository<Borrowing, Long> {

}
