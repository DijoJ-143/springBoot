package com.ust.lms.services;

import com.ust.lms.model.Borrowing;

public interface BorrowingServices {

	Borrowing borrowBook(Long bookid, Long memberId);

	Borrowing returnBook(Long borrowingId);
}
