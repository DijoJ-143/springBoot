package com.ust.lms.servicesImplementation;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.lms.model.Borrowing;
import com.ust.lms.repository.BookRepository;
import com.ust.lms.repository.BorrowingReopsitory;
import com.ust.lms.repository.MemberRepository;
import com.ust.lms.services.BorrowingServices;

@Service
public class BorrowingServiceImpl implements BorrowingServices {
	@Autowired
	BookRepository bookrepo;

	@Autowired
	MemberRepository memberRepo;

	@Autowired
	BorrowingReopsitory borrowingRepo;

	@Override
	public Borrowing borrowBook(Long bookid, Long memberId) {
		try {
			Borrowing b = new Borrowing();
			b.setBook(bookrepo.findById(bookid).get());
			b.setMember(memberRepo.findById(memberId).get());
			b.setBorrowedDate(new Date());
			return borrowingRepo.save(b);

		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}

	}

	@Override
	public Borrowing returnBook(Long borrowingId) {

		Borrowing b = borrowingRepo.findById(borrowingId).get();

		b.setReturnDate(new Date());

		return borrowingRepo.save(b);
	}

}
