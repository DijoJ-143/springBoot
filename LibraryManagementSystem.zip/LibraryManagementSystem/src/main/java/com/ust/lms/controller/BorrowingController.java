package com.ust.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import com.ust.lms.model.Borrowing;
import com.ust.lms.repository.BookRepository;
import com.ust.lms.repository.MemberRepository;
import com.ust.lms.services.BorrowingServices;

@Controller
public class BorrowingController {

	@Autowired
	BorrowingServices borrowingService;

	@Autowired
	BookRepository bookrepo;

	@Autowired
	MemberRepository memberrepo;

	@GetMapping("/borrow")
	public String showBorrow(Model model) {
		model.addAttribute("books", bookrepo.findAll());
		model.addAttribute("members", memberrepo.findAll());
		return "create_borrow"; // Return the borrow form
	}

	@PostMapping("/borrow")
	public String borrowPost(@RequestParam("memberId") Long memberID, @RequestParam("bookId") Long bookID, Model m) {

		Borrowing b = borrowingService.borrowBook(bookID, memberID);
		m.addAttribute("message", "Successfully borrowed the book.");
		if (b != null) {
			return "status";

		} else
			return "error";

	}

	// Exception handler for catching validation exceptions globally
	@ExceptionHandler(Exception.class)
	public String handleException(Exception e, ModelMap model) {
		model.addAttribute("message", e.getMessage());
		return "error"; // Show a generic error page if any unexpected error occurs
	}
}
