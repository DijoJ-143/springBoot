package com.ust.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ust.lms.model.Book;
import com.ust.lms.model.Member;
import com.ust.lms.repository.BookRepository;

@Controller
public class BookController {

	@Autowired
	private BookRepository brepo;
	
	

	// get mapping
	@GetMapping("/")
	public String listsBook(Model model) {
		model.addAttribute("books", brepo.findAll());
		return "books";
	}

	@GetMapping("/book/new")
	public String addBook(Model model) {
		Book b = new Book();
		model.addAttribute("book", b);
		return "create_book";
	}

	

	// post mapping

	@PostMapping("/books")
	public String saveBook(Book book) {
		brepo.save(book);
		return "redirect:/";
	}
	
	

	

}
